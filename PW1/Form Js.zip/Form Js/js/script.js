var nome = document.querySelector("#txNome")

var sobrenome = document.querySelector("#txSobrenome")

var eMail = document.querySelector("#txEmail")

var dataNascimento = document.querySelector("#txDataNascimento")

var telefone = document.querySelector("#txTelefone")

var assunto = document.querySelector("#txAssunto")

var mensagem = document.querySelector("#txMensagem")

var btDados = document.querySelector("Button")

var resultado = document.querySelector("#resultado")

btDados.addEventListener('click',exibirDados)

function exibirDados() {

  resultado.innerHTML = `
    <p> Nome: ${nome.value}</p>
    <p> Sobrenome: ${sobrenome.value}</p>
    <p> E-Mail: ${eMail.value}</p>
    <p> Data Nascimento: ${dataNascimento.value}</p>
    <p> Telefone: ${telefone.value}</p>
    <p> Assunto: ${assunto.value}</p>
    <p> Mensagem: ${mensagem.value}</p>

`
    
    
    
    
    
 
    
    
}